package bunnyhunt;

    
/**
 * Represents a bush. Bushes don't do anything, they're just there.
 */
public class Bush {
}

