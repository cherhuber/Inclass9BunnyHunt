package bunnyhunt;

public class Bunny extends Animal {

    public Bunny(Model model, int row, int column) {
        super(model, row, column);
    }
    
//    @Override
//    int decideMove() {
//        return random(Model.MIN_DIRECTION, Model.MAX_DIRECTION);
//    }
}


